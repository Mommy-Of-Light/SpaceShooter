﻿using Microsoft.VisualBasic.Devices;

namespace SpaceShooter
{
    public class MenuScreen : GameScreen
    {
        private SpriteFont _font;
        private SpriteFont _font_title;
        private List<Button> _buttons;
        private KeyboardState _previousKeyboard;
        public MenuScreen(Game1 game) : base(game)
        {
            _previousKeyboard = Microsoft.Xna.Framework.Input.Keyboard.GetState();
            Game.ChangeScreenSize(500, 500);
        }

        public override void Initialize()
        {
            _font = Game.Content.Load<SpriteFont>("Fonts/SpaceInvader_12"); _font_title = Game.Content.Load<SpriteFont>("Fonts/SpaceInvader_16");

            _buttons = new List<Button>();

            int screenWidth = Game.GraphicsDevice.Viewport.Width;
            int screenHeight = Game.GraphicsDevice.Viewport.Height;

            int buttonWidth = 350;
            int buttonHeight = 60;

            int x = (screenWidth - buttonWidth) / 2;
            int startY = 100;
            int spacing = 75;

            _buttons.Add(new Button("New Game", new XnaRectangle(x, startY, buttonWidth, buttonHeight)));
            _buttons.Add(new Button("Save", new XnaRectangle(x, startY + spacing, buttonWidth, buttonHeight)));
            _buttons.Add(new Button("Archive", new XnaRectangle(x, startY + spacing * 2, buttonWidth, buttonHeight)));
            _buttons.Add(new Button("Ranking", new XnaRectangle(x, startY + spacing * 3, buttonWidth, buttonHeight)));
            _buttons.Add(new Button("Exit", new XnaRectangle(x, startY + spacing * 4, buttonWidth, buttonHeight)));
        }

        public override void Update(GameTime gameTime, KeyboardState keyboard, Vector2 mousePosition, bool mouseClicked)
        {
            if (keyboard.IsKeyDown(XnaKeys.Escape) && _previousKeyboard.IsKeyUp(XnaKeys.Escape))
            {
                Game.Exit();
            }

            foreach (Button button in _buttons)
            {
                button.Update(mousePosition);

                if (button.IsClicked(mousePosition, mouseClicked))
                {
                    HandleButton(button.Text);
                    break;
                }
            }

            _previousKeyboard = keyboard;
        }

        private void HandleButton(string button)
        {
            switch (button)
            {
                case "New Game":
                    Game.ScreenManager.ChangeScreen(new NewGameScreen(Game));
                    break;

                case "Save":
                    Game.ScreenManager.ChangeScreen(new SaveScreen(Game));
                    break;

                case "Archive":
                    Game.ScreenManager.ChangeScreen(new ArchiveScreen(Game));
                    break;

                case "Ranking":
                    Game.ScreenManager.ChangeScreen(new RankingScreen(Game));
                    break;

                case "Exit":
                    Game.Exit();
                    break;
            }
        }

        public override void Draw(GameTime gameTime, SpriteBatch spriteBatch)
        {
            spriteBatch.Begin();

            spriteBatch.Draw(Game.Content.Load<Texture2D>("Textures/Background/black"), Vector2.Zero, XnaColor.White);

            int screenWidth = Game.GraphicsDevice.Viewport.Width;

            string title = "SPACE SHOOTER";

            Vector2 titleSize = _font_title.MeasureString(title);

            spriteBatch.DrawString(_font_title, title, new Vector2((screenWidth - titleSize.X) / 2, 50), XnaColor.White);

            foreach (Button button in _buttons)
            {
                button.Draw(spriteBatch, _font);
            }

            spriteBatch.End();
        }
    }
}
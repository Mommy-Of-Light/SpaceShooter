﻿namespace SpaceShooter
{
    public class UpgradeScreen : GameScreen
    {
        private SpriteFont _font;
        private SpriteFont _titleFont;
        private Button _fireRateButton;
        private Button _pierceButton;
        private Button _missileButton;
        private Button _damageButton;
        private KeyboardState _previousKeyboard;
        private PlayScreen _playScreen;
        private const int MaxPierce = 10;
        private const int MaxMissiles = 15;
        private const int MaxShotsUntilMissile = 1;
        private List<Button> _buttons;

        public UpgradeScreen(Game1 game, PlayScreen playScreen) : base(game)
        {
            _playScreen = playScreen;
            _previousKeyboard = Keyboard.GetState();
            Game.ChangeScreenSize(500, 500);
        }

        public override void Initialize()
        {
            _font = Game.Content.Load<SpriteFont>("Fonts/SpaceInvader_12");
            _titleFont = Game.Content.Load<SpriteFont>("Fonts/SpaceInvader_16");

            _fireRateButton = new Button("MISSILE ATK SPD ++ (1)", new XnaRectangle(100, 130, 300, 50));
            _pierceButton = new Button("PIERCE +1 (2)", new XnaRectangle(100, 200, 300, 50));
            _missileButton = new Button("MISSILE +1 (3)", new XnaRectangle(100, 270, 300, 50));
            _damageButton = new Button("DAMAGE +1 (4)", new XnaRectangle(100, 340, 300, 50));

            _buttons = new List<Button>
            {
                _fireRateButton,
                _pierceButton,
                _missileButton,
                _damageButton
            };

            if (_buttons.Count > 0)
            {
                _buttons[0].SetSelected(true);
            }

            UpdateButtonStates();
        }

        public override void Update(GameTime gameTime, KeyboardState keyboard, Vector2 mousePosition, bool mouseClicked)
        {
            _fireRateButton.Update(mousePosition);
            _pierceButton.Update(mousePosition);
            _missileButton.Update(mousePosition);
            _damageButton.Update(mousePosition);

            if (_fireRateButton.IsClicked(mousePosition, mouseClicked))
            {
                ChooseUpgrade(0);
                return;
            }

            if (_pierceButton.IsClicked(mousePosition, mouseClicked))
            {
                ChooseUpgrade(1);
                return;
            }

            if (_missileButton.IsClicked(mousePosition, mouseClicked))
            {
                ChooseUpgrade(2);
                return;
            }

            if (_damageButton.IsClicked(mousePosition, mouseClicked))
            {
                ChooseUpgrade(3);
                return;
            }

            if ((keyboard.IsKeyDown(XnaKeys.D1) &&_previousKeyboard.IsKeyUp(XnaKeys.D1)) || (keyboard.IsKeyDown(XnaKeys.NumPad1) &&_previousKeyboard.IsKeyUp(XnaKeys.NumPad1)) &&!_fireRateButton.IsLocked)
            {
                ChooseUpgrade(0);
                return;
            }

            if ((keyboard.IsKeyDown(XnaKeys.D2) &&_previousKeyboard.IsKeyUp(XnaKeys.D2)) || (keyboard.IsKeyDown(XnaKeys.NumPad2) &&_previousKeyboard.IsKeyUp(XnaKeys.NumPad2)) &&!_pierceButton.IsLocked)
            {
                ChooseUpgrade(1);
                return;
            }

            if ((keyboard.IsKeyDown(XnaKeys.D3) && _previousKeyboard.IsKeyUp(XnaKeys.D3)) || (keyboard.IsKeyDown(XnaKeys.NumPad3) && _previousKeyboard.IsKeyUp(XnaKeys.NumPad3)) &&!_missileButton.IsLocked)
            {
                ChooseUpgrade(2);
                return;
            }

            if ((keyboard.IsKeyDown(XnaKeys.D4) && _previousKeyboard.IsKeyUp(XnaKeys.D4)) || (keyboard.IsKeyDown(XnaKeys.NumPad4) && _previousKeyboard.IsKeyUp(XnaKeys.NumPad4)) &&!_damageButton.IsLocked)
            {
                ChooseUpgrade(3);
                return;
            }

            if (keyboard.IsKeyDown(XnaKeys.Up) &&
    _previousKeyboard.IsKeyUp(XnaKeys.Up))
            {
                int selectedIndex = _buttons.FindIndex(b => b.IsSelected);

                if (selectedIndex == -1)
                {
                    _buttons[0].SetSelected(true);
                }
                else
                {
                    _buttons[selectedIndex].SetSelected(false);

                    int newIndex =
                        (selectedIndex - 1 + _buttons.Count) % _buttons.Count;

                    _buttons[newIndex].SetSelected(true);
                }
            }

            if (keyboard.IsKeyDown(XnaKeys.Down) &&
                _previousKeyboard.IsKeyUp(XnaKeys.Down))
            {
                int selectedIndex = _buttons.FindIndex(b => b.IsSelected);

                if (selectedIndex == -1)
                {
                    _buttons[0].SetSelected(true);
                }
                else
                {
                    _buttons[selectedIndex].SetSelected(false);

                    int newIndex =
                        (selectedIndex + 1) % _buttons.Count;

                    _buttons[newIndex].SetSelected(true);
                }
            }

            if ((keyboard.IsKeyDown(XnaKeys.Enter) &&
                 _previousKeyboard.IsKeyUp(XnaKeys.Enter)) ||
                (keyboard.IsKeyDown(XnaKeys.Space) &&
                 _previousKeyboard.IsKeyUp(XnaKeys.Space)))
            {
                int selectedIndex = _buttons.FindIndex(b => b.IsSelected);

                if (selectedIndex != -1 &&
                    !_buttons[selectedIndex].IsLocked)
                {
                    ChooseUpgrade(selectedIndex);
                    return;
                }
            }

            _previousKeyboard = keyboard;
        }

        private void UpdateButtonStates()
        {
            _fireRateButton.SetLocked(
                _playScreen.Player.ShotsUntilMissile <= MaxShotsUntilMissile
            );

            _pierceButton.SetLocked(
                _playScreen.Player.Pierce >= MaxPierce
            );

            _missileButton.SetLocked(
                _playScreen.Player.AutoAimMissiles >= MaxMissiles
            );
        }

        private void ChooseUpgrade(int upgrade)
        {
            Game.ChangeScreenSize(500, 800);
            _playScreen.ApplyUpgrade(upgrade);
            Game.ScreenManager.ReturnToScreen(_playScreen);
        }

        public override void Draw(GameTime gameTime, SpriteBatch spriteBatch)
        {
            spriteBatch.Begin();

            Texture2D background = Game.Content.Load<Texture2D>("Textures/Background/black");
            spriteBatch.Draw(background, Vector2.Zero, XnaColor.White);

            string title = "CHOOSE UPGRADE";
            Vector2 titleSize = _titleFont.MeasureString(title);
            spriteBatch.DrawString(_titleFont, title, new Vector2((Game.GraphicsDevice.Viewport.Width - titleSize.X) / 2f, 50), XnaColor.White);

            _fireRateButton.Draw(spriteBatch, _font);
            _pierceButton.Draw(spriteBatch, _font);
            _missileButton.Draw(spriteBatch, _font);
            _damageButton.Draw(spriteBatch, _font);

            spriteBatch.End();
        }
    }
}